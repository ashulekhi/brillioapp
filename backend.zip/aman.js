export default "100 rs"

export var money1 = 200